package executor

import (
	"strings"
	"sync"
	"time"

	"github.com/router-for-me/CLIProxyAPI/v8/internal/config"
	cliproxyauth "github.com/router-for-me/CLIProxyAPI/v8/sdk/cliproxy/auth"
)

// Per-credential daily request accounting for Antigravity.
//
// Session affinity concentrates a conversation on one credential, so a heavy
// day piles every attempt onto a small number of identities. Community
// incident analysis (#7768) flags single-credential concentration as a ban
// signal and the 2026-11-13 lane risk model records the ~200 requests/day
// heuristic with an 80-100/day comfort band, so the cap parks a credential
// with an end-of-UTC-day short cooldown once its configured attempt count is
// reached, letting the selector rotate to sibling credentials.
//
// The counter is process-local on purpose: a restart resets it, which errs
// toward serving rather than toward locking credentials out, and the heuristic
// it defends against spans far longer than any restart window.
type antigravityDailyCapState struct {
	mu     sync.Mutex
	day    string
	counts map[string]int
}

var antigravityDailyCap = antigravityDailyCapState{counts: make(map[string]int)}

func antigravityDailyCapLimit(cfg *config.Config) int {
	if cfg == nil || cfg.Antigravity.PerCredentialDailyCap <= 0 {
		return 0
	}
	return cfg.Antigravity.PerCredentialDailyCap
}

func antigravityDailyCapDay(now time.Time) string {
	return now.UTC().Format("2006-01-02")
}

func (s *antigravityDailyCapState) roll(now time.Time) {
	day := antigravityDailyCapDay(now)
	if s.day != day {
		s.day = day
		s.counts = make(map[string]int)
	}
}

// antigravityDailyCapRemainingSeconds reports how long until the current UTC
// day ends, which is how long a capped credential stays parked.
func antigravityDailyCapRemainingSeconds(now time.Time) int {
	end := now.UTC().Truncate(24 * time.Hour).Add(24 * time.Hour)
	remaining := int(end.Sub(now).Seconds())
	if remaining < 1 {
		remaining = 1
	}
	return remaining
}

// antigravityDailyCapExceeded reports whether the credential has already used
// its configured daily attempt budget. A zero cap disables the check.
func antigravityDailyCapExceeded(auth *cliproxyauth.Auth, cfg *config.Config) bool {
	limit := antigravityDailyCapLimit(cfg)
	if limit <= 0 || auth == nil || strings.TrimSpace(auth.ID) == "" {
		return false
	}
	now := time.Now()
	antigravityDailyCap.mu.Lock()
	defer antigravityDailyCap.mu.Unlock()
	antigravityDailyCap.roll(now)
	return antigravityDailyCap.counts[auth.ID] >= limit
}

// antigravityDailyCapRecord counts one upstream attempt for the credential.
func antigravityDailyCapRecord(auth *cliproxyauth.Auth) {
	if auth == nil || strings.TrimSpace(auth.ID) == "" {
		return
	}
	now := time.Now()
	antigravityDailyCap.mu.Lock()
	defer antigravityDailyCap.mu.Unlock()
	antigravityDailyCap.roll(now)
	antigravityDailyCap.counts[auth.ID]++
}

func resetAntigravityDailyCapForTest() {
	antigravityDailyCap.mu.Lock()
	defer antigravityDailyCap.mu.Unlock()
	antigravityDailyCap.day = ""
	antigravityDailyCap.counts = make(map[string]int)
}

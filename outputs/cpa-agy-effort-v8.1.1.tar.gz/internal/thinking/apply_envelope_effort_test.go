package thinking_test

import (
	"testing"

	"github.com/MoeForge/moego/ojson"
	"github.com/router-for-me/CLIProxyAPI/v8/internal/registry"
	"github.com/router-for-me/CLIProxyAPI/v8/internal/thinking"
	_ "github.com/router-for-me/CLIProxyAPI/v8/internal/thinking/provider/antigravity"
)

// antigravityEnvelope is what the antigravity translator emits for a Responses
// request: the level lands in request.generationConfig.thinkingConfig, outside
// the body the caller sent. ExtractEnvelopeLevelForTest mirrors the copy
// ApplyRequestThinkingWithModelInfo performs before the shared pass, so these
// tests pin what the provider would otherwise be handed.
func antigravityEnvelope(level string) string {
	if level == "" {
		return "{\"request\":{\"contents\":[]}}"
	}
	return "{\"request\":{\"generationConfig\":{\"thinkingConfig\":{\"thinkingLevel\":\"" + level + "\",\"includeThoughts\":true}}}}"
}

const (
	sourceNoLevel = "{\"instructions\":\"sys\",\"input\":[{\"type\":\"message\",\"role\":\"user\",\"content\":[{\"type\":\"input_text\",\"text\":\"hi\"}]}]}"
	sourceLow     = "{\"reasoning\":{\"effort\":\"low\"},\"input\":[{\"type\":\"message\",\"role\":\"user\",\"content\":[{\"type\":\"input_text\",\"text\":\"hi\"}]}]}"
)

func antigravityClaudeInfo() *registry.ModelInfo {
	return &registry.ModelInfo{
		ID:       "claude-sonnet-5-5-high",
		Type:     "anthropic",
		Thinking: &registry.ThinkingSupport{Levels: []string{"minimal", "low", "medium", "high"}},
	}
}

func applyEnvelope(t *testing.T, envelope, source string) string {
	t.Helper()
	info := antigravityClaudeInfo()
	got, errApply := thinking.ApplyThinkingWithModelInfo([]byte(envelope), []byte(source), info.ID, "openai-response", "antigravity", "antigravity", info)
	if errApply != nil {
		t.Fatalf("ApplyThinkingWithModelInfo() error = %v", errApply)
	}
	return ojson.GetBytesNoCopy(got, "request.generationConfig.thinkingConfig.thinkingLevel").String()
}

func TestApplyThinkingUsesAntigravityEnvelopeLevel(t *testing.T) {
	if got := applyEnvelope(t, antigravityEnvelope("xhigh"), sourceNoLevel); got != "HIGH" {
		t.Fatalf("unsupported xhigh applied as %q, want the highest supported level", got)
	}
	if got := applyEnvelope(t, antigravityEnvelope("medium"), sourceNoLevel); got != "MEDIUM" {
		t.Fatalf("supported level applied as %q, want medium", got)
	}
	if got := applyEnvelope(t, antigravityEnvelope("xhigh"), sourceLow); got != "LOW" {
		t.Fatalf("explicit source level applied as %q, want low", got)
	}
	if got := applyEnvelope(t, antigravityEnvelope(""), sourceNoLevel); got != "" {
		t.Fatalf("envelope without a level produced %q, want none", got)
	}
}

func TestExtractReasoningEffortConfigPrefix(t *testing.T) {
	prefix := "request.generationConfig.thinkingConfig"
	if got := thinking.ExtractReasoningEffortConfigPrefix([]byte(antigravityEnvelope("XHIGH")), prefix+"."); got.Mode != thinking.ModeLevel || got.Level != thinking.LevelXHigh {
		t.Fatalf("extracted %+v, want the xhigh level", got)
	}
	snake := "{\"request\":{\"generationConfig\":{\"thinkingConfig\":{\"thinking_level\":\"medium\"}}}}"
	if got := thinking.ExtractReasoningEffortConfigPrefix([]byte(snake), prefix); got.Level != thinking.LevelMedium {
		t.Fatalf("snake_case level extracted %+v, want medium", got)
	}
	if got := thinking.ExtractReasoningEffortConfigPrefix([]byte(antigravityEnvelope("high")), ""); got != (thinking.ThinkingConfig{}) {
		t.Fatalf("empty prefix extracted %+v, want the zero config", got)
	}
	budgetOnly := "{\"request\":{\"generationConfig\":{\"thinkingConfig\":{\"thinkingBudget\":8192}}}}"
	if got := thinking.ExtractReasoningEffortConfigPrefix([]byte(budgetOnly), prefix); got != (thinking.ThinkingConfig{}) {
		t.Fatalf("budget-only envelope extracted %+v, want the zero config", got)
	}
}

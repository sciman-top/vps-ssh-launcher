package helps_test

import (
	"context"
	"net/http"
	"testing"

	"github.com/MoeForge/moego/ojson"
	internalconfig "github.com/router-for-me/CLIProxyAPI/v8/internal/config"
	"github.com/router-for-me/CLIProxyAPI/v8/internal/registry"
	helps "github.com/router-for-me/CLIProxyAPI/v8/internal/runtime/executor/helps"
	_ "github.com/router-for-me/CLIProxyAPI/v8/internal/thinking/provider/antigravity"
	_ "github.com/router-for-me/CLIProxyAPI/v8/internal/thinking/provider/gemini"
	_ "github.com/router-for-me/CLIProxyAPI/v8/internal/translator"
	cliproxyauth "github.com/router-for-me/CLIProxyAPI/v8/sdk/cliproxy/auth"
	cliproxyexecutor "github.com/router-for-me/CLIProxyAPI/v8/sdk/cliproxy/executor"
	sdktranslator "github.com/router-for-me/CLIProxyAPI/v8/sdk/translator"
)

type summaryRemovingPluginHooks struct {
	t *testing.T
}

func (h *summaryRemovingPluginHooks) NormalizeRequest(_ context.Context, _, _ sdktranslator.Format, _ string, body []byte, _ bool) []byte {
	h.t.Helper()
	const path = "generationConfig.thinkingConfig.includeThoughts"
	if !ojson.GetBytes(body, path).Bool() {
		h.t.Fatalf("request normalizer did not receive enabled summary: %s", body)
	}
	out, _ := ojson.DeleteBytes(body, path)
	return out
}

func (*summaryRemovingPluginHooks) TranslateRequest(context.Context, sdktranslator.Format, sdktranslator.Format, string, []byte, bool) ([]byte, bool) {
	return nil, false
}

func (*summaryRemovingPluginHooks) NormalizeResponseBefore(context.Context, sdktranslator.Format, sdktranslator.Format, string, []byte, []byte, []byte, bool) []byte {
	return nil
}

func (*summaryRemovingPluginHooks) TranslateResponse(context.Context, sdktranslator.Format, sdktranslator.Format, string, []byte, []byte, []byte, bool) ([]byte, bool) {
	return nil, false
}

func (*summaryRemovingPluginHooks) NormalizeResponseAfter(context.Context, sdktranslator.Format, sdktranslator.Format, string, []byte, []byte, []byte, bool) []byte {
	return nil
}

func TestApplyThinkingWithSourcePayloadPreservesNormalizerSummaryRemoval(t *testing.T) {
	hooks := &summaryRemovingPluginHooks{t: t}
	sdktranslator.SetPluginHooks(hooks)
	t.Cleanup(func() { sdktranslator.SetPluginHooks(nil) })

	source := []byte(`{"model":"gemini-3.6-flash","reasoning":{"effort":"high","summary":"auto"},"input":"hi"}`)
	translated := sdktranslator.TranslateRequest(
		sdktranslator.FormatOpenAIResponse,
		sdktranslator.FormatGemini,
		"gemini-3.6-flash",
		source,
		false,
	)
	const summaryPath = "generationConfig.thinkingConfig.includeThoughts"
	if ojson.GetBytes(translated, summaryPath).Exists() {
		t.Fatalf("request normalizer did not remove summary: %s", translated)
	}

	out, err := helps.ApplyThinkingWithSourcePayload(
		translated,
		source,
		source,
		"gemini-3.6-flash",
		sdktranslator.FormatOpenAIResponse.String(),
		sdktranslator.FormatGemini.String(),
		"gemini",
	)
	if err != nil {
		t.Fatalf("ApplyThinkingWithSourcePayload() error = %v", err)
	}
	if ojson.GetBytes(out, summaryPath).Exists() {
		t.Fatalf("executor restored summary removed by request normalizer: %s", out)
	}
}

func TestApplyThinkingWithSourcePayloadPreservesOriginalOnlySummary(t *testing.T) {
	currentSource := []byte(`{"model":"gemini-3.6-flash","input":"hi"}`)
	originalSource := []byte(`{"model":"gemini-3.6-flash","reasoning":{"summary":null},"input":"hi"}`)
	body := []byte(`{"generationConfig":{"thinkingConfig":{"thinkingLevel":"high"}}}`)

	out, err := helps.ApplyThinkingWithSourcePayload(
		body,
		currentSource,
		originalSource,
		"gemini-3.6-flash",
		sdktranslator.FormatOpenAIResponse.String(),
		sdktranslator.FormatGemini.String(),
		"gemini",
	)
	if err != nil {
		t.Fatalf("ApplyThinkingWithSourcePayload() error = %v", err)
	}
	if include := ojson.GetBytes(out, "generationConfig.thinkingConfig.includeThoughts"); !include.Exists() || include.Bool() {
		t.Fatalf("original disabled summary was not preserved: %s", out)
	}
}

func TestApplyThinkingWithSourcePayload_AntigravityClaudeThinkingDisplayUpdates(t *testing.T) {
	source := []byte(`{"model":"gemini-3.8-flash-high","max_tokens":4096,"thinking":{"type":"adaptive","display":"updates"},"messages":[{"role":"user","content":"Hello, think first."}]}`)
	translated := sdktranslator.TranslateRequest(
		sdktranslator.FormatClaude,
		sdktranslator.FormatAntigravity,
		"gemini-3.8-flash-high",
		source,
		false,
	)

	out, err := helps.ApplyThinkingWithSourcePayload(
		translated,
		source,
		source,
		"gemini-3.8-flash-high",
		sdktranslator.FormatClaude.String(),
		sdktranslator.FormatAntigravity.String(),
		"antigravity",
	)
	if err != nil {
		t.Fatalf("ApplyThinkingWithSourcePayload() error = %v", err)
	}
	include := ojson.GetBytes(out, "request.generationConfig.thinkingConfig.includeThoughts")
	if !include.Exists() || !include.Bool() {
		t.Fatalf("includeThoughts not enabled: %s", out)
	}
	level := ojson.GetBytes(out, "request.generationConfig.thinkingConfig.thinkingLevel").String()
	if level != "HIGH" {
		t.Fatalf("thinkingLevel = %q, want HIGH: %s", level, out)
	}
}

func TestApplyThinkingWithSourcePayload_AntigravityResponsesReasoningSummaryAuto(t *testing.T) {
	source := []byte(`{"model":"gemini-3.8-flash-high","reasoning":{"effort":"low","summary":"auto"},"input":"hi"}`)
	translated := sdktranslator.TranslateRequest(
		sdktranslator.FormatOpenAIResponse,
		sdktranslator.FormatAntigravity,
		"gemini-3.8-flash-high",
		source,
		false,
	)

	out, err := helps.ApplyThinkingWithSourcePayload(
		translated,
		source,
		source,
		"gemini-3.8-flash-high",
		sdktranslator.FormatOpenAIResponse.String(),
		sdktranslator.FormatAntigravity.String(),
		"antigravity",
	)
	if err != nil {
		t.Fatalf("ApplyThinkingWithSourcePayload() error = %v", err)
	}
	include := ojson.GetBytes(out, "request.generationConfig.thinkingConfig.includeThoughts")
	if !include.Exists() || !include.Bool() {
		t.Fatalf("includeThoughts not enabled: %s", out)
	}
	level := ojson.GetBytes(out, "request.generationConfig.thinkingConfig.thinkingLevel").String()
	if level != "LOW" {
		t.Fatalf("thinkingLevel = %q, want LOW: %s", level, out)
	}
}

func TestApplyRequestThinking_AntigravityClaude55PreservesThinkingLevel(t *testing.T) {
	for _, model := range []string{"claude-sonnet-5-5-high", "claude-opus-5-5-high"} {
		for _, tc := range []struct {
			level string
			want  string
		}{
			{level: "low", want: "LOW"},
			{level: "medium", want: "MEDIUM"},
			{level: "high", want: "HIGH"},
		} {
			level := tc.level
			t.Run(model+"/"+level, func(t *testing.T) {
				source := []byte(`{"contents":[{"role":"user","parts":[{"text":"Reply OK"}]}],"generationConfig":{"maxOutputTokens":128000,"thinkingConfig":{"includeThoughts":true,"thinkingLevel":"` + level + `"}}}`)
				translated := sdktranslator.TranslateRequest(
					sdktranslator.FormatGemini,
					sdktranslator.FormatAntigravity,
					model,
					source,
					true,
				)

				out, err := helps.ApplyThinkingWithSourcePayload(
					translated,
					source,
					source,
					model,
					sdktranslator.FormatGemini.String(),
					sdktranslator.FormatAntigravity.String(),
					"antigravity",
				)
				if err != nil {
					t.Fatalf("ApplyThinkingWithSourcePayload() error = %v", err)
				}
				if got := ojson.GetBytes(out, "request.generationConfig.thinkingConfig.thinkingLevel").String(); got != tc.want {
					t.Fatalf("thinkingLevel = %q, want %q: %s", got, tc.want, out)
				}
				if budget := ojson.GetBytes(out, "request.generationConfig.thinkingConfig.thinkingBudget"); budget.Exists() {
					t.Fatalf("thinkingBudget should be absent, got %s: %s", budget.Raw, out)
				}
				if include := ojson.GetBytes(out, "request.generationConfig.thinkingConfig.includeThoughts"); !include.Exists() || !include.Bool() {
					t.Fatalf("includeThoughts = %s, want true: %s", include.Raw, out)
				}
			})
		}
	}
}

type antigravityEnvelopeExecutor struct {
	targetFormat string
	translated   []byte
}

func (e *antigravityEnvelopeExecutor) Identifier() string { return "antigravity" }

func (e *antigravityEnvelopeExecutor) run(req cliproxyexecutor.Request, opts cliproxyexecutor.Options) ([]byte, error) {
	if e.translated == nil {
		e.translated = sdktranslator.TranslateRequest(opts.SourceFormat, sdktranslator.FormatAntigravity, req.Model, req.Payload, opts.Stream)
	}
	doc := ojson.NewDoc(e.translated)
	if err := helps.ApplyRequestThinkingDoc(doc, req, opts, opts.SourceFormat.String(), e.targetFormat, e.Identifier()); err != nil {
		return nil, err
	}
	return doc.Bytes(), nil
}

func (e *antigravityEnvelopeExecutor) Execute(_ context.Context, _ *cliproxyauth.Auth, req cliproxyexecutor.Request, opts cliproxyexecutor.Options) (cliproxyexecutor.Response, error) {
	out, err := e.run(req, opts)
	return cliproxyexecutor.Response{Payload: out}, err
}

func (e *antigravityEnvelopeExecutor) ExecuteStream(ctx context.Context, auth *cliproxyauth.Auth, req cliproxyexecutor.Request, opts cliproxyexecutor.Options) (*cliproxyexecutor.StreamResult, error) {
	resp, err := e.Execute(ctx, auth, req, opts)
	if err != nil {
		return nil, err
	}
	chunks := make(chan cliproxyexecutor.StreamChunk, 1)
	chunks <- cliproxyexecutor.StreamChunk{Payload: resp.Payload}
	close(chunks)
	return &cliproxyexecutor.StreamResult{Chunks: chunks}, nil
}

func (*antigravityEnvelopeExecutor) Refresh(_ context.Context, auth *cliproxyauth.Auth) (*cliproxyauth.Auth, error) {
	return auth, nil
}

func (e *antigravityEnvelopeExecutor) CountTokens(ctx context.Context, auth *cliproxyauth.Auth, req cliproxyexecutor.Request, opts cliproxyexecutor.Options) (cliproxyexecutor.Response, error) {
	return e.Execute(ctx, auth, req, opts)
}

func (*antigravityEnvelopeExecutor) HttpRequest(context.Context, *cliproxyauth.Auth, *http.Request) (*http.Response, error) {
	return nil, nil
}

// A Responses turn addressed to an antigravity Claude model carries its effort at
// reasoning.effort, while the translated envelope holds it at
// request.generationConfig.thinkingConfig.thinkingLevel. The model is registered
// only up to "high", so an xhigh turn must reach upstream as high rather than as
// an unsupported level the upstream substitutes on its own.
func TestApplyRequestThinkingDocAntigravityClaudeClampsEnvelopeLevel(t *testing.T) {
	manager := cliproxyauth.NewManager(nil, nil, nil)
	manager.SetConfig(&internalconfig.Config{})
	executor := &antigravityEnvelopeExecutor{targetFormat: sdktranslator.FormatAntigravity.String()}
	manager.RegisterExecutor(executor)
	auth := &cliproxyauth.Auth{ID: "antigravity-claude", Provider: "antigravity"}
	modelRegistry := registry.GetGlobalRegistry()
	modelRegistry.RegisterClient(auth.ID, auth.Provider, []*registry.ModelInfo{{
		ID: "claude-sonnet-5-5-high", Type: "anthropic",
		Thinking: &registry.ThinkingSupport{Levels: []string{"minimal", "low", "medium", "high"}},
	}})
	t.Cleanup(func() { modelRegistry.UnregisterClient(auth.ID) })
	if _, errRegister := manager.Register(t.Context(), auth); errRegister != nil {
		t.Fatalf("Register() error = %v", errRegister)
	}
	for _, tc := range []struct{ effort, want string }{
		{"xhigh", "HIGH"},
		{"medium", "MEDIUM"},
	} {
		t.Run(tc.effort, func(t *testing.T) {
			executor.translated = nil
			original := []byte("{\"instructions\":\"sys\",\"reasoning\":{\"effort\":\"" + tc.effort + "\"},\"input\":[{\"type\":\"message\",\"role\":\"user\",\"content\":[{\"type\":\"input_text\",\"text\":\"Reply OK\"}]}]}")
			req := cliproxyexecutor.Request{Model: "claude-sonnet-5-5-high", Payload: original, Format: sdktranslator.FormatOpenAIResponse}
			opts := cliproxyexecutor.Options{SourceFormat: sdktranslator.FormatOpenAIResponse, OriginalRequest: original}
			resp, err := executor.Execute(t.Context(), auth, req, opts)
			if err != nil {
				t.Fatalf("Execute() error = %v", err)
			}
			if got := ojson.GetBytes(resp.Payload, "request.generationConfig.thinkingConfig.thinkingLevel").String(); got != tc.want {
				t.Fatalf("thinkingLevel = %q, want %q: %s", got, tc.want, resp.Payload)
			}
		})
	}
}

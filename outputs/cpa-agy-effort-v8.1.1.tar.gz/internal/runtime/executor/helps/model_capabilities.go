package helps

import (
	"fmt"
	"strings"

	"github.com/MoeForge/moego/ojson"
	"github.com/router-for-me/CLIProxyAPI/v8/internal/registry"
	"github.com/router-for-me/CLIProxyAPI/v8/internal/thinking"
	cliproxyauth "github.com/router-for-me/CLIProxyAPI/v8/sdk/cliproxy/auth"
	cliproxyexecutor "github.com/router-for-me/CLIProxyAPI/v8/sdk/cliproxy/executor"
	sdktranslator "github.com/router-for-me/CLIProxyAPI/v8/sdk/translator"
)

// APIKeyModelIsCompat reports whether the selected API-key model enables
// compatibility handling for Claude thinking blocks.
func APIKeyModelIsCompat(req cliproxyexecutor.Request) bool {
	modelInfo, ok := cliproxyauth.ResolvedModelInfo(req)
	return ok && modelInfo != nil && modelInfo.IsCompat
}

// ApplyRequestThinking preserves the registry lookup path unless the auth
// manager bound authoritative model capabilities to this execution attempt.
func ApplyRequestThinking(body []byte, req cliproxyexecutor.Request, opts cliproxyexecutor.Options, fromFormat, toFormat, provider string, normalizedUpdatesChanged ...bool) ([]byte, error) {
	return ApplyRequestThinkingWithModelInfo(body, req, opts, fromFormat, toFormat, provider, nil, normalizedUpdatesChanged...)
}

// ApplyRequestThinkingDoc applies request thinking onto doc in place, preserving
// the registry lookup path unless the auth manager bound authoritative model
// capabilities to this execution attempt.
func ApplyRequestThinkingDoc(doc *ojson.Doc, req cliproxyexecutor.Request, opts cliproxyexecutor.Options, fromFormat, toFormat, providerKey string, PreserveConfigurationUpdates ...bool) error {
	return ApplyRequestThinkingWithModelInfoDoc(doc, req, opts, fromFormat, toFormat, providerKey, nil, PreserveConfigurationUpdates...)
}

// sourceWithEnvelopeReasoningEffort returns the source body with a reasoning
// level copied from the translated envelope when the caller did not state one.
// An explicit body or suffix level always wins. The copy is what lets the shared
// thinking pass validate and clamp the level the provider will actually execute
// (an antigravity Claude model on this gateway is registered only up to "high",
// while the codex catalog of the same lane offers "xhigh"); without it the level
// reaching upstream is whatever the translation step happened to emit.
func sourceWithEnvelopeReasoningEffort(envelope, source []byte, fromFormat, provider, model string) []byte {
	prefix := reasoningEffortConfigPrefix(provider)
	if prefix == "" || len(source) == 0 || thinking.HasThinkingSuffix(model) || thinkingRequestCarriesLevel(source, fromFormat) {
		return source
	}
	if len(envelope) == 0 {
		return source
	}
	level := thinking.ExtractReasoningEffortConfigPrefix(envelope, prefix)
	if level.Level == "" {
		return source
	}
	return withReasoningEffortLevel(source, level.Level)
}

// reasoningEffortConfigPrefix names where a provider's translated envelope keeps
// its thinking level when the source request format does not, or "" when the
// envelope carries no such prefix. Only Antigravity wraps the generation config
// in a request object.
func reasoningEffortConfigPrefix(provider string) string {
	if strings.ToLower(strings.TrimSpace(provider)) != "antigravity" {
		return ""
	}
	return "request.generationConfig.thinkingConfig"
}

// thinkingEnvelopeLevelApplies reports whether a translated envelope can carry a
// reasoning level the shared pass would otherwise re-derive. Only the Gemini and
// Responses source formats keep the level in the body; an envelope-only level is
// copied onto those sources, and a source that already states its own block wins.
func thinkingEnvelopeLevelApplies(fromFormat string) bool {
	switch strings.ToLower(strings.TrimSpace(fromFormat)) {
	case "openai-response", "codex", "openai", "gemini":
		return true
	default:
		return false
	}
}

// thinkingRequestCarriesLevel reports whether the caller's own body already
// specifies a reasoning level for this source format, so an envelope-derived
// level must not override it.
func thinkingRequestCarriesLevel(body []byte, fromFormat string) bool {
	switch strings.ToLower(strings.TrimSpace(fromFormat)) {
	case "openai-response", "codex":
		return ojson.GetBytesNoCopy(body, "reasoning.effort").Exists()
	case "openai":
		return ojson.GetBytesNoCopy(body, "reasoning_effort").Exists() ||
			ojson.GetBytesNoCopy(body, "reasoning.effort").Exists()
	default:
		return true
	}
}

// withReasoningEffortLevel returns the source body with its reasoning level set,
// so the shared thinking pass validates and clamps the value the provider will
// execute instead of the level it would re-derive from the translated body.
func withReasoningEffortLevel(body []byte, level thinking.ThinkingLevel) []byte {
	if len(level) == 0 {
		return body
	}
	doc := ojson.NewDoc(body)
	if doc == nil {
		return body
	}
	// Keep the caller's shape: a Chat Completions body carries reasoning_effort,
	// a Responses body carries the nested reasoning.effort.
	path := "reasoning.effort"
	if !ojson.GetBytesNoCopy(body, "reasoning").IsObject() && ojson.GetBytesNoCopy(body, "reasoning_effort").Exists() {
		path = "reasoning_effort"
	}
	if errSet := doc.Set(path, string(level)); errSet != nil {
		return body
	}
	out := doc.Bytes()
	if !ojson.ValidBytes(out) {
		return body
	}
	return out
}

// ApplyRequestThinkingWithModelInfo applies request thinking and falls back to
// fallbackModelInfo when neither request metadata nor the global registry
// resolves a model definition.
func ApplyRequestThinkingWithModelInfo(body []byte, req cliproxyexecutor.Request, opts cliproxyexecutor.Options, fromFormat, toFormat, provider string, fallbackModelInfo *registry.ModelInfo, normalizedUpdatesChanged ...bool) ([]byte, error) {
	originalSource := opts.OriginalRequest
	if len(originalSource) == 0 {
		originalSource = req.Payload
	}
	source := req.Payload
	if len(source) == 0 {
		source = opts.OriginalRequest
	}
	summaryConfig := translatedRequestSummaryConfig(body, req.Payload, originalSource, req.Model, fromFormat, toFormat)
	source = sourceWithEnvelopeReasoningEffort(body, source, fromFormat, provider, req.Model)
	var out []byte
	var err error
	if modelInfo, ok := cliproxyauth.ResolvedModelInfo(req); ok {
		out, err = thinking.ApplyThinkingWithModelInfoAndSummary(body, source, req.Model, fromFormat, toFormat, provider, modelInfo, summaryConfig, normalizedUpdatesChanged...)
	} else {
		out, err = thinking.ApplyThinkingWithFallbackModelInfoAndSummary(body, source, req.Model, fromFormat, toFormat, provider, fallbackModelInfo, summaryConfig, normalizedUpdatesChanged...)
	}
	if err != nil {
		return out, err
	}
	if shouldReconcileClaudeOpenAICompatToolCallReasoning(req, fromFormat, toFormat) && len(out) > 0 {
		doc := ojson.NewDoc(out)
		if reconcileClaudeOpenAICompatToolCallReasoningDoc(doc) {
			out = doc.Bytes()
		}
	}
	return out, nil
}

// ApplyRequestThinkingWithModelInfoDoc applies request thinking onto doc in place
// and falls back to fallbackModelInfo when neither request metadata nor the global
// registry resolves a model definition.
func ApplyRequestThinkingWithModelInfoDoc(doc *ojson.Doc, req cliproxyexecutor.Request, opts cliproxyexecutor.Options, fromFormat, toFormat, provider string, fallbackModelInfo *registry.ModelInfo, normalizedUpdatesChanged ...bool) error {
	if doc == nil {
		return nil
	}
	originalSource := opts.OriginalRequest
	if len(originalSource) == 0 {
		originalSource = req.Payload
	}
	source := req.Payload
	if len(source) == 0 {
		source = opts.OriginalRequest
	}
	summaryConfig := translatedRequestSummaryConfigDoc(sdktranslator.Default(), doc, req.Payload, originalSource, req.Model, fromFormat, toFormat)
	// The envelope level is what the provider will execute; it only needs to be
	// consulted when the caller's body did not carry a level of its own (an
	// explicit body or suffix level always wins).
	if !thinking.HasThinkingSuffix(req.Model) && thinkingEnvelopeLevelApplies(fromFormat) && !thinkingRequestCarriesLevel(source, fromFormat) && doc != nil {
		if level := thinking.ExtractReasoningEffortConfigPrefixDoc(doc, reasoningEffortConfigPrefix(provider)); level.Level != "" {
			source = withReasoningEffortLevel(source, level.Level)
		}
	}
	var err error
	if modelInfo, ok := cliproxyauth.ResolvedModelInfo(req); ok {
		err = thinking.ApplyThinkingWithModelInfoAndSummaryDoc(doc, source, req.Model, fromFormat, toFormat, provider, modelInfo, summaryConfig, normalizedUpdatesChanged...)
	} else {
		err = thinking.ApplyThinkingWithFallbackModelInfoAndSummaryDoc(doc, source, req.Model, fromFormat, toFormat, provider, fallbackModelInfo, summaryConfig, normalizedUpdatesChanged...)
	}
	if err != nil {
		return err
	}
	if shouldReconcileClaudeOpenAICompatToolCallReasoning(req, fromFormat, toFormat) {
		reconcileClaudeOpenAICompatToolCallReasoningDoc(doc)
	}
	return nil
}

func shouldReconcileClaudeOpenAICompatToolCallReasoning(req cliproxyexecutor.Request, fromFormat, toFormat string) bool {
	return APIKeyModelIsCompat(req) &&
		strings.EqualFold(strings.TrimSpace(fromFormat), "claude") &&
		strings.EqualFold(strings.TrimSpace(toFormat), "openai")
}

func reconcileClaudeOpenAICompatToolCallReasoningDoc(doc *ojson.Doc) bool {
	if doc == nil || doc.Len() == 0 {
		return false
	}
	messages := doc.Get("messages")
	if !messages.Exists() || !messages.IsArray() {
		return false
	}
	reasoningActive := false
	if effortRes := doc.Get("reasoning_effort"); effortRes.Exists() {
		resolvedEffort := strings.ToLower(strings.TrimSpace(effortRes.String()))
		if resolvedEffort != "" && resolvedEffort != string(thinking.LevelNone) && resolvedEffort != "0" && resolvedEffort != "false" {
			reasoningActive = true
		}
	}

	modified := false
	for idx, msg := range messages.Array() {
		if strings.TrimSpace(msg.Get("role").String()) != "assistant" {
			continue
		}
		toolCalls := msg.Get("tool_calls")
		if !toolCalls.Exists() || !toolCalls.IsArray() || len(toolCalls.Array()) == 0 {
			continue
		}
		reasoning := msg.Get("reasoning_content")
		if reasoningActive {
			if !reasoning.Exists() || (strings.TrimSpace(reasoning.String()) == "" && reasoning.String() != " ") {
				if doc.Set(fmt.Sprintf("messages.%d.reasoning_content", idx), " ") == nil {
					modified = true
				}
			}
			continue
		}
		if reasoning.Exists() && strings.TrimSpace(reasoning.String()) == "" {
			if doc.Delete(fmt.Sprintf("messages.%d.reasoning_content", idx)) == nil {
				modified = true
			}
		}
	}
	return modified
}

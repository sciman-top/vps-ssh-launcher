package executor

import (
	"bufio"
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/MoeForge/moego/json"
	"github.com/MoeForge/moego/ojson"
	"github.com/router-for-me/CLIProxyAPI/v8/internal/clienterror"
	"github.com/router-for-me/CLIProxyAPI/v8/internal/runtime/executor/helps"
	"github.com/router-for-me/CLIProxyAPI/v8/internal/thinking"
	"github.com/router-for-me/CLIProxyAPI/v8/internal/util"
	cliproxyauth "github.com/router-for-me/CLIProxyAPI/v8/sdk/cliproxy/auth"
	cliproxyexecutor "github.com/router-for-me/CLIProxyAPI/v8/sdk/cliproxy/executor"
	sdktranslator "github.com/router-for-me/CLIProxyAPI/v8/sdk/translator"
	log "github.com/sirupsen/logrus"
)

// Execute performs a non-streaming request to the Antigravity API.
func (e *AntigravityExecutor) Execute(ctx context.Context, auth *cliproxyauth.Auth, req cliproxyexecutor.Request, opts cliproxyexecutor.Options) (resp cliproxyexecutor.Response, err error) {
	if helps.HasResponsesCompactionItem(req.Payload) {
		expanded, errExpand := helps.ExpandAntigravityCompactionCapsules(req.Payload)
		if errExpand != nil {
			return resp, statusErr{code: http.StatusBadRequest, msg: errExpand.Error()}
		}
		req.Payload = expanded
		if len(opts.OriginalRequest) > 0 {
			expandedOrig, errOrig := helps.ExpandAntigravityCompactionCapsules(opts.OriginalRequest)
			if errOrig == nil {
				opts.OriginalRequest = expandedOrig
			} else {
				opts.OriginalRequest = expanded
			}
		}
	}
	if opts.Alt == "responses/compact" || helps.HasResponsesCompactionTrigger(req.Payload) || helps.HasResponsesCompactionTrigger(opts.OriginalRequest) {
		return e.executeCompaction(ctx, auth, req, opts)
	}
	baseModel := thinking.ParseSuffix(req.Model).ModelName
	if antigravityInTOSPause(e.cfg, auth) {
		return resp, newAntigravityTOSPauseStatusErr()
	}
	if !antigravityCoolingDisabled(auth, e.cfg) {
		if inCooldown, remaining, errCooldown := antigravityIsInShortCooldownRequired(ctx, auth, baseModel, time.Now()); errCooldown != nil {
			return resp, homeKVUnavailableStatusErr(errCooldown)
		} else if inCooldown && !antigravityShouldBypassShortCooldown(ctx, e.cfg) {
			log.Debugf("antigravity executor: auth %s in short cooldown for model %s (%s remaining), returning 429 to switch auth", auth.ID, baseModel, remaining)
			d := remaining
			return resp, statusErr{code: http.StatusTooManyRequests, msg: fmt.Sprintf("auth in short cooldown, %s remaining", remaining), retryAfter: &d}
		}
	}

	if antigravityDailyCapExceeded(auth, e.cfg) {
		capRemaining := antigravityDailyCapRemainingSeconds(time.Now())
		if !antigravityCoolingDisabled(auth, e.cfg) {
			if errMark := markAntigravityShortCooldownRequired(ctx, auth, baseModel, time.Now(), time.Duration(capRemaining)*time.Second); errMark != nil {
				return resp, homeKVUnavailableStatusErr(errMark)
			}
		}
		log.Debugf("antigravity executor: auth %s hit the daily cap on model %s, parking until UTC day rollover (%d seconds remaining)", auth.ID, baseModel, capRemaining)
		capDuration := time.Duration(capRemaining) * time.Second
		return resp, statusErr{code: http.StatusTooManyRequests, msg: fmt.Sprintf("antigravity daily credential cap reached, %d seconds remaining", capRemaining), retryAfter: &capDuration}
	}
	antigravityDailyCapRecord(auth)

	lowerModel := strings.ToLower(baseModel)
	isClaude := strings.Contains(lowerModel, "claude")
	if isClaude || strings.Contains(lowerModel, "gemini-3-pro") || strings.Contains(lowerModel, "gemini-3.1-flash-image") {
		return e.executeClaudeNonStream(ctx, auth, req, opts)
	}

	reporter := helps.NewExecutorUsageReporter(ctx, e, baseModel, auth)
	defer reporter.TrackFailure(ctx, &err)

	from := opts.SourceFormat
	responseFormat := cliproxyexecutor.ResponseFormatOrSource(opts)
	to := sdktranslator.FromString("antigravity")

	originalPayloadSource := req.Payload
	if len(opts.OriginalRequest) > 0 {
		originalPayloadSource = opts.OriginalRequest
	}
	originalPayload := originalPayloadSource
	originalPayload, errValidate := validateAntigravityRequestSignatures(ctx, baseModel, from, originalPayload)
	if errValidate != nil {
		return resp, errValidate
	}
	req.Payload = originalPayload
	// Observe a translation refusal before the token refresh or any upstream call.
	modelInfo, _ := cliproxyauth.ResolvedModelInfo(req)
	translationReq := sdktranslator.RequestEnvelope{Format: from, Model: baseModel, ModelInfo: modelInfo}
	originalTranslated, translated, errTranslate := helps.TranslateRequestEnvelopePairWithCodexMultiAgentV2(ctx, opts.Headers, e.cfg, from, to, translationReq, originalPayload, req.Payload)
	if errTranslate != nil {
		return resp, errTranslate
	}
	token, updatedAuth, errToken := e.ensureAccessToken(ctx, auth)
	if errToken != nil {
		return resp, errToken
	}
	if updatedAuth != nil {
		auth = updatedAuth
		reporter.UpdateAccessTokenFingerprint(auth)
	}

	doc := ojson.NewDoc(translated)
	if err = helps.ApplyRequestThinkingDoc(doc, req, opts, from.String(), to.String(), e.Identifier()); err != nil {
		return resp, err
	}

	finalize := helps.NewPayloadFinalizer(e.cfg, e.Identifier(), baseModel, "antigravity", "request", originalTranslated, req, opts)
	ctx = helps.WithPayloadFinalizer(ctx, finalize)
	e.obfuscateSensitiveWordsDoc(doc)
	sanitizeAntigravityGeminiRequestSignaturesDoc(baseModel, doc)

	useCredits := cliproxyauth.AntigravityCreditsRequested(ctx) && antigravityCreditsRetryEnabled(e.cfg)

	baseURL := resolveAntigravityRequestBaseURL(auth)
	httpClient := newAntigravityHTTPClient(ctx, e.cfg, auth, 0)
	httpClient = reporter.TrackHTTPClient(httpClient)
	// Credential retry rounds are owned by the conductor. Perform one upstream
	// request per credential so request-retry is not consumed twice.
	if useCredits {
		if injectEnabledCreditTypesDoc(doc) {
			helps.MarkCreditsUsed(ctx)
		}
	}
	replayScope := antigravityReasoningReplayScope{}
	if antigravityUsesReasoningReplayCache(baseModel) {
		var errReplay error
		replayScope, _, errReplay = prepareAntigravityGeminiReasoningReplayPayloadDoc(ctx, baseModel, req, opts, doc)
		if errReplay != nil {
			err = errReplay
			return resp, err
		}
	}
	ensureAntigravityGeminiBoundaryUserContentDoc(baseModel, doc)
	var replayRequestPayload []byte
	if replayScope.valid() {
		replayRequestPayload, _ = antigravityReplayRequestEnvelopeFromDoc(doc)
	}

	httpReq, requestPayload, errReq := e.buildRequestDoc(ctx, auth, token, baseModel, doc, false, opts.Alt, baseURL, helps.AntigravitySessionIDForAuth(antigravityAuthID(auth), opts.Metadata, req.Metadata))
	if errReq != nil {
		err = errReq
		return resp, err
	}
	translated = requestPayload
	reporter.SetTranslatedRequestMetadata(requestPayload, to.String())

	httpResp, errDo := helps.WithAntigravityHTTPClientTrace(httpClient, auth, "generate").Do(httpReq)
	if errDo != nil {
		helps.RecordAPIResponseError(ctx, e.cfg, errDo)
		if errors.Is(errDo, context.Canceled) || errors.Is(errDo, context.DeadlineExceeded) {
			return resp, errDo
		}
		err = errDo
		return resp, err
	}

	helps.RecordAPIResponseMetadata(ctx, e.cfg, httpResp.StatusCode, httpResp.Header.Clone())
	bodyBytes, errRead := io.ReadAll(httpResp.Body)
	if errClose := httpResp.Body.Close(); errClose != nil {
		log.Errorf("antigravity executor: close response body error: %v", errClose)
	}
	helps.AppendAPIResponseChunk(ctx, e.cfg, bodyBytes)
	if errRead != nil {
		helps.RecordAPIResponseError(ctx, e.cfg, errRead)
		err = errRead
		return resp, err
	}

	if httpResp.StatusCode < http.StatusOK || httpResp.StatusCode >= http.StatusMultipleChoices {
		log.Debugf("antigravity executor: upstream error status: %d, body: %s", httpResp.StatusCode, helps.SummarizeErrorBody(httpResp.Header.Get("Content-Type"), bodyBytes))
		err = e.applyAntigravityUpstreamError(ctx, auth, baseModel, useCredits, replayScope, httpResp.StatusCode, httpResp.Header, bodyBytes)
		return resp, err
	}

	// Surface any in-band JSON error payload on HTTP 2xx immediately with its
	// upstream status and 429/403/401/replay bookkeeping instead of clearing
	// credits failure state or falling through to translation.
	if errorResult := ojson.GetBytesNoCopy(bodyBytes, "error"); errorResult.Exists() && errorResult.Type != ojson.Null {
		statusCode := antigravityInBandErrorStatusCode(errorResult)
		log.Debugf("antigravity executor: upstream in-band error status: %d", statusCode)
		err = e.applyAntigravityUpstreamError(ctx, auth, baseModel, useCredits, replayScope, statusCode, httpResp.Header, bodyBytes)
		helps.RecordAPIResponseError(ctx, e.cfg, err)
		return resp, err
	}

	// Success
	reporter.ObserveResponseModel(bodyBytes)
	if _, zeroErrMsg, zeroOutput := helps.CheckGeminiZeroOutputNonStream(responseFormat, bodyBytes, true); zeroOutput {
		antiDetail := helps.ParseAntigravityUsage(bodyBytes)
		helps.ApplyGeminiRequestImageConfig(&antiDetail, requestPayload)
		err = newGeminiZeroOutputStatusErr(zeroErrMsg)
		helps.RecordAPIResponseError(ctx, e.cfg, err)
		reporter.PublishFailureWithDetail(ctx, antiDetail, err)
		return cliproxyexecutor.Response{}, err
	}
	rawResponseBody := bodyBytes
	bodyBytes = e.resolveWebSearchGroundingURLs(ctx, auth, from, originalPayload, translated, bodyBytes)
	var param any
	converted := sdktranslator.TranslateNonStream(ctx, to, responseFormat, req.Model, helps.ApplyPatchOriginalRequest(req, opts), translated, bodyBytes, &param)
	if helps.ApplyPatchTranslationError(param) != nil || len(converted) == 0 {
		return cliproxyexecutor.Response{}, statusErr{code: http.StatusBadGateway, msg: helps.ApplyPatchUpstreamErrorMessage}
	}
	if errPayload, okErr := helps.TranslatedClaudeErrorPayload(responseFormat, converted); okErr {
		err = newGeminiTranslatedClaudeErrorStatusErr(errPayload)
		antiDetail := helps.ParseAntigravityUsage(bodyBytes)
		helps.ApplyGeminiRequestImageConfig(&antiDetail, requestPayload)
		reporter.PublishFailureWithDetail(ctx, antiDetail, err)
		return cliproxyexecutor.Response{}, err
	}
	if len(replayRequestPayload) == 0 {
		replayRequestPayload = requestPayload
	}
	cacheAntigravityReasoningReplayFromResponse(ctx, replayScope, replayRequestPayload, rawResponseBody)
	if useCredits {
		clearAntigravityCreditsFailureState(auth)
	}
	antiDetail := helps.ParseAntigravityUsage(bodyBytes)
	helps.ApplyGeminiRequestImageConfig(&antiDetail, requestPayload)
	reporter.Publish(ctx, antiDetail)
	if responseFormat == sdktranslator.FormatOpenAIResponse {
		converted = helps.EnsureResponsesUsageDetails(converted)
	}
	resp = cliproxyexecutor.Response{Payload: converted, Headers: httpResp.Header.Clone()}
	reporter.EnsurePublished(ctx)
	return resp, nil
}

func (e *AntigravityExecutor) executeCompaction(ctx context.Context, auth *cliproxyauth.Auth, req cliproxyexecutor.Request, opts cliproxyexecutor.Options) (resp cliproxyexecutor.Response, err error) {
	baseModel := thinking.ParseSuffix(req.Model).ModelName
	payload := req.Payload
	if len(payload) == 0 && len(opts.OriginalRequest) > 0 {
		payload = opts.OriginalRequest
	}
	summaryPayload := helps.PrepareAntigravityCompactionSummaryPayload(payload, baseModel)

	summaryReq := cliproxyexecutor.Request{
		Model:    req.Model,
		Payload:  summaryPayload,
		Metadata: req.Metadata,
	}
	summaryOpts := opts
	summaryOpts.Alt = ""
	summaryOpts.Stream = false
	summaryOpts.OriginalRequest = nil
	summaryOpts.SourceFormat = sdktranslator.FormatOpenAIResponse
	summaryOpts.ResponseFormat = sdktranslator.FormatOpenAIResponse

	summaryResp, errSummary := e.Execute(ctx, auth, summaryReq, summaryOpts)
	if errSummary != nil {
		return resp, errSummary
	}

	summaryText, errExtract := helps.ExtractAntigravitySummaryText(summaryResp.Payload)
	if errExtract != nil {
		return resp, fmt.Errorf("extract summary: %w", errExtract)
	}
	capsule, errSeal := helps.SealAntigravityCompaction(summaryText, baseModel)
	if errSeal != nil {
		return resp, fmt.Errorf("seal compaction capsule: %w", errSeal)
	}

	inputTokens := int(ojson.GetBytesNoCopy(summaryResp.Payload, "usage.input_tokens").Int())
	outputTokens := int(ojson.GetBytesNoCopy(summaryResp.Payload, "usage.output_tokens").Int())
	totalTokens := int(ojson.GetBytesNoCopy(summaryResp.Payload, "usage.total_tokens").Int())
	if totalTokens == 0 && inputTokens == 0 {
		usage := helps.ParseOpenAIUsage(summaryResp.Payload)
		inputTokens = int(usage.InputTokens)
		outputTokens = int(usage.OutputTokens)
		totalTokens = int(usage.TotalTokens)
	}

	respBytes := helps.BuildAntigravityCompactionResponse(baseModel, capsule, inputTokens, outputTokens, totalTokens)
	return cliproxyexecutor.Response{
		Payload: respBytes,
		Headers: summaryResp.Headers,
	}, nil
}

// executeClaudeNonStream performs a claude non-streaming request to the Antigravity API.
func (e *AntigravityExecutor) executeClaudeNonStream(ctx context.Context, auth *cliproxyauth.Auth, req cliproxyexecutor.Request, opts cliproxyexecutor.Options) (resp cliproxyexecutor.Response, err error) {
	baseModel := thinking.ParseSuffix(req.Model).ModelName
	if antigravityInTOSPause(e.cfg, auth) {
		return resp, newAntigravityTOSPauseStatusErr()
	}
	if !antigravityCoolingDisabled(auth, e.cfg) {
		if inCooldown, remaining, errCooldown := antigravityIsInShortCooldownRequired(ctx, auth, baseModel, time.Now()); errCooldown != nil {
			return resp, homeKVUnavailableStatusErr(errCooldown)
		} else if inCooldown && !antigravityShouldBypassShortCooldown(ctx, e.cfg) {
			log.Debugf("antigravity executor: auth %s in short cooldown for model %s (%s remaining), returning 429 to switch auth", auth.ID, baseModel, remaining)
			d := remaining
			return resp, statusErr{code: http.StatusTooManyRequests, msg: fmt.Sprintf("auth in short cooldown, %s remaining", remaining), retryAfter: &d}
		}
	}

	reporter := helps.NewExecutorUsageReporter(ctx, e, baseModel, auth)
	defer reporter.TrackFailure(ctx, &err)

	from := opts.SourceFormat
	responseFormat := cliproxyexecutor.ResponseFormatOrSource(opts)
	to := sdktranslator.FromString("antigravity")

	originalPayloadSource := req.Payload
	if len(opts.OriginalRequest) > 0 {
		originalPayloadSource = opts.OriginalRequest
	}
	originalPayload := originalPayloadSource
	originalPayload, errValidate := validateAntigravityRequestSignatures(ctx, baseModel, from, originalPayload)
	if errValidate != nil {
		return resp, errValidate
	}
	req.Payload = originalPayload
	// Observe a translation refusal before the token refresh or any upstream call.
	modelInfo, _ := cliproxyauth.ResolvedModelInfo(req)
	translationReq := sdktranslator.RequestEnvelope{Format: from, Model: baseModel, Stream: true, ModelInfo: modelInfo}
	originalTranslated, translated, errTranslate := helps.TranslateRequestEnvelopePairWithCodexMultiAgentV2(ctx, opts.Headers, e.cfg, from, to, translationReq, originalPayload, req.Payload)
	if errTranslate != nil {
		return resp, errTranslate
	}
	token, updatedAuth, errToken := e.ensureAccessToken(ctx, auth)
	if errToken != nil {
		return resp, errToken
	}
	if updatedAuth != nil {
		auth = updatedAuth
		reporter.UpdateAccessTokenFingerprint(auth)
	}

	doc := ojson.NewDoc(translated)
	if err = helps.ApplyRequestThinkingDoc(doc, req, opts, from.String(), to.String(), e.Identifier()); err != nil {
		return resp, err
	}

	finalize := helps.NewPayloadFinalizer(e.cfg, e.Identifier(), baseModel, "antigravity", "request", originalTranslated, req, opts)
	ctx = helps.WithPayloadFinalizer(ctx, finalize)
	e.obfuscateSensitiveWordsDoc(doc)
	sanitizeAntigravityGeminiRequestSignaturesDoc(baseModel, doc)

	useCredits := cliproxyauth.AntigravityCreditsRequested(ctx) && antigravityCreditsRetryEnabled(e.cfg)

	baseURL := resolveAntigravityRequestBaseURL(auth)
	httpClient := newAntigravityHTTPClient(ctx, e.cfg, auth, 0)
	httpClient = reporter.TrackHTTPClient(httpClient)

	// Credential retry rounds are owned by the conductor. Perform one upstream
	// request per credential so request-retry is not consumed twice.
	if useCredits {
		if injectEnabledCreditTypesDoc(doc) {
			helps.MarkCreditsUsed(ctx)
		}
	}
	replayScope := antigravityReasoningReplayScope{}
	if antigravityUsesReasoningReplayCache(baseModel) {
		var errReplay error
		replayScope, _, errReplay = prepareAntigravityGeminiReasoningReplayPayloadDoc(ctx, baseModel, req, opts, doc)
		if errReplay != nil {
			err = errReplay
			return resp, err
		}
	}
	ensureAntigravityGeminiBoundaryUserContentDoc(baseModel, doc)
	var replayRequestPayload []byte
	if replayScope.valid() {
		replayRequestPayload, _ = antigravityReplayRequestEnvelopeFromDoc(doc)
	}
	httpReq, requestPayload, errReq := e.buildRequestDoc(ctx, auth, token, baseModel, doc, true, opts.Alt, baseURL, helps.AntigravitySessionIDForAuth(antigravityAuthID(auth), opts.Metadata, req.Metadata))
	if errReq != nil {
		err = errReq
		return resp, err
	}
	translated = requestPayload
	reporter.SetTranslatedRequestMetadata(requestPayload, to.String())

	httpResp, errDo := helps.WithAntigravityHTTPClientTrace(httpClient, auth, "generate").Do(httpReq)
	if errDo != nil {
		helps.RecordAPIResponseError(ctx, e.cfg, errDo)
		if errors.Is(errDo, context.Canceled) || errors.Is(errDo, context.DeadlineExceeded) {
			return resp, errDo
		}
		err = errDo
		return resp, err
	}
	helps.RecordAPIResponseMetadata(ctx, e.cfg, httpResp.StatusCode, httpResp.Header.Clone())
	if httpResp.StatusCode < http.StatusOK || httpResp.StatusCode >= http.StatusMultipleChoices {
		bodyBytes, errRead := io.ReadAll(httpResp.Body)
		if errClose := httpResp.Body.Close(); errClose != nil {
			log.Errorf("antigravity executor: close response body error: %v", errClose)
		}
		helps.AppendAPIResponseChunk(ctx, e.cfg, bodyBytes)
		if errRead != nil {
			helps.RecordAPIResponseError(ctx, e.cfg, errRead)
			if errors.Is(errRead, context.Canceled) || errors.Is(errRead, context.DeadlineExceeded) {
				err = errRead
				return resp, err
			}
			if errCtx := ctx.Err(); errCtx != nil {
				err = errCtx
				return resp, err
			}
			err = errRead
			return resp, err
		}
		err = e.applyAntigravityUpstreamError(ctx, auth, baseModel, useCredits, replayScope, httpResp.StatusCode, httpResp.Header, bodyBytes)
		return resp, err
	}

	if len(replayRequestPayload) == 0 {
		replayRequestPayload = requestPayload
	}
	replayAccumulator := newAntigravityReasoningReplayAccumulator(replayScope, replayRequestPayload)
	var rawPayloads [][]byte
	var pendingFilterPayload []byte
	var pendingFilterMsg string
	sseJSON := helps.NewSSEJSONAssembler(streamScannerBuffer)
	scanner := bufio.NewScanner(httpResp.Body)
	scanner.Buffer(nil, streamScannerBuffer)
	for scanner.Scan() {
		line := scanner.Bytes()
		helps.AppendAPIResponseChunk(ctx, e.cfg, line)
		payload := sseJSON.Push(line)
		if payload == nil {
			continue
		}
		// Surface any mid-stream JSON error frame on HTTP 200 immediately with its
		// upstream status and 429/TOS/replay bookkeeping instead of letting it
		// degrade into a synthetic zero-output 502 or truncated HTTP 200 response.
		if errorResult := ojson.GetBytesNoCopy(payload, "error"); errorResult.Exists() && errorResult.Type != ojson.Null {
			statusCode := antigravityInBandErrorStatusCode(errorResult)
			if errClose := httpResp.Body.Close(); errClose != nil {
				log.Errorf("antigravity executor: close response body error: %v", errClose)
			}
			err = e.applyAntigravityUpstreamError(ctx, auth, baseModel, useCredits, replayScope, statusCode, nil, payload)
			helps.RecordAPIResponseError(ctx, e.cfg, err)
			reporter.PublishFailure(ctx, err)
			return resp, err
		}
		if replayAccumulator != nil {
			replayAccumulator.ObserveSSELine(payload)
		}
		if len(pendingFilterPayload) > 0 {
			reporter.ObserveResponseModel(pendingFilterPayload)
			rawPayloads = append(rawPayloads, pendingFilterPayload)
			pendingFilterPayload = nil
			pendingFilterMsg = ""
		}
		if filterMsg, blocked := clienterror.GeminiFilterBlockMessage(payload); blocked {
			pendingFilterPayload = bytes.Clone(payload)
			pendingFilterMsg = filterMsg
			continue
		}
		reporter.ObserveResponseModel(payload)
		rawPayloads = append(rawPayloads, bytes.Clone(payload))
	}
	scanErr := scanner.Err()
	if errClose := httpResp.Body.Close(); errClose != nil {
		log.Errorf("antigravity executor: close response body error: %v", errClose)
	}
	if scanErr != nil {
		helps.RecordAPIResponseError(ctx, e.cfg, scanErr)
		reporter.PublishFailure(ctx, scanErr)
		return resp, scanErr
	}
	if pendingFilterMsg != "" {
		filterErr := statusErr{code: http.StatusBadRequest, msg: pendingFilterMsg}
		helps.RecordAPIResponseError(ctx, e.cfg, filterErr)
		reporter.PublishFailure(ctx, filterErr)
		return resp, filterErr
	}
	aggregatedPayload := e.convertStreamChunksToNonStream(rawPayloads)
	reporter.ObserveResponseModel(aggregatedPayload)
	if _, zeroErrMsg, zeroOutput := helps.CheckGeminiZeroOutputNonStream(responseFormat, aggregatedPayload, true); zeroOutput {
		antiDetail := helps.ParseAntigravityUsage(aggregatedPayload)
		helps.ApplyGeminiRequestImageConfig(&antiDetail, requestPayload)
		err = newGeminiZeroOutputStatusErr(zeroErrMsg)
		helps.RecordAPIResponseError(ctx, e.cfg, err)
		reporter.PublishFailureWithDetail(ctx, antiDetail, err)
		return cliproxyexecutor.Response{}, err
	}
	resp = cliproxyexecutor.Response{Payload: aggregatedPayload}

	resp.Payload = e.resolveWebSearchGroundingURLs(ctx, auth, from, originalPayload, translated, resp.Payload)
	reporter.ObserveResponseModel(resp.Payload)
	var param any
	converted := sdktranslator.TranslateNonStream(ctx, to, responseFormat, req.Model, helps.ApplyPatchOriginalRequest(req, opts), translated, resp.Payload, &param)
	if helps.ApplyPatchTranslationError(param) != nil || len(converted) == 0 {
		return cliproxyexecutor.Response{}, statusErr{code: http.StatusBadGateway, msg: helps.ApplyPatchUpstreamErrorMessage}
	}
	if errPayload, okErr := helps.TranslatedClaudeErrorPayload(responseFormat, converted); okErr {
		err = newGeminiTranslatedClaudeErrorStatusErr(errPayload)
		antiDetail := helps.ParseAntigravityUsage(resp.Payload)
		helps.ApplyGeminiRequestImageConfig(&antiDetail, requestPayload)
		reporter.PublishFailureWithDetail(ctx, antiDetail, err)
		return cliproxyexecutor.Response{}, err
	}
	if replayAccumulator != nil {
		replayAccumulator.Commit(ctx)
	}
	if useCredits {
		clearAntigravityCreditsFailureState(auth)
	}
	antiDetail := helps.ParseAntigravityUsage(resp.Payload)
	helps.ApplyGeminiRequestImageConfig(&antiDetail, requestPayload)
	reporter.Publish(ctx, antiDetail)
	if responseFormat == sdktranslator.FormatOpenAIResponse {
		converted = helps.EnsureResponsesUsageDetails(converted)
	}
	resp = cliproxyexecutor.Response{Payload: converted, Headers: httpResp.Header.Clone()}
	reporter.EnsurePublished(ctx)

	return resp, nil
}

const antigravityPartsPlaceholder = `"__cpa_parts_placeholder__"`

func (e *AntigravityExecutor) convertStreamToNonStream(stream []byte) []byte {
	var chunks [][]byte
	remaining := stream
	for len(remaining) > 0 {
		var line []byte
		if nl := bytes.IndexByte(remaining, '\n'); nl >= 0 {
			line = remaining[:nl]
			remaining = remaining[nl+1:]
		} else {
			line = remaining
			remaining = nil
		}
		if trimmed := bytes.TrimSpace(line); len(trimmed) > 0 {
			chunks = append(chunks, trimmed)
		}
	}
	return e.convertStreamChunksToNonStream(chunks)
}

func (e *AntigravityExecutor) convertStreamChunksToNonStream(chunks [][]byte) []byte {
	var (
		responseNodeRaw         string
		responsePartsRaw        string
		responsePartsIndex      int
		traceID                 string
		finishReason            string
		modelVersion            string
		responseID              string
		role                    string
		usageRaw                string
		parts                   []string
		pendingKind             string
		pendingText             strings.Builder
		pendingThoughtSig       string
		pendingFromCurrentChunk bool
	)

	flushPending := func() {
		if pendingKind == "" {
			return
		}
		text := pendingText.String()
		switch pendingKind {
		case "text":
			if text == "" && pendingThoughtSig == "" {
				pendingKind = ""
				pendingText.Reset()
				pendingThoughtSig = ""
				pendingFromCurrentChunk = false
				return
			}
			part := map[string]any{"text": text}
			if pendingThoughtSig != "" {
				part["thoughtSignature"] = pendingThoughtSig
			}
			encoded, _ := json.Marshal(part)
			parts = append(parts, string(encoded))
		case "thought":
			if text == "" && pendingThoughtSig == "" {
				pendingKind = ""
				pendingText.Reset()
				pendingThoughtSig = ""
				pendingFromCurrentChunk = false
				return
			}
			part := map[string]any{"thought": true, "text": text}
			if pendingThoughtSig != "" {
				part["thoughtSignature"] = pendingThoughtSig
			}
			encoded, _ := json.Marshal(part)
			parts = append(parts, string(encoded))
		}
		pendingKind = ""
		pendingText.Reset()
		pendingThoughtSig = ""
		pendingFromCurrentChunk = false
	}

	normalizeRawPart := func(partResult ojson.Result, hasSnakeSig, hasSnakeInline bool, sig string, inlineRaw string) string {
		if !hasSnakeSig && !hasSnakeInline {
			return partResult.Raw
		}
		partDoc := ojson.NewDoc([]byte(partResult.Raw))
		if hasSnakeSig {
			if sig != "" {
				_ = partDoc.Set("thoughtSignature", sig)
			}
			_ = partDoc.Delete("thought_signature")
		}
		if hasSnakeInline {
			if inlineRaw != "" {
				_ = partDoc.SetRawBytes("inlineData", []byte(inlineRaw))
			}
			_ = partDoc.Delete("inline_data")
		}
		return string(partDoc.Bytes())
	}

	for _, line := range chunks {
		trimmed := bytes.TrimSpace(line)
		if len(trimmed) == 0 || !ojson.ValidBytes(trimmed) {
			continue
		}

		root := util.GetGJSONBytesNoCopy(trimmed, "@this")
		responseNode := root.Get("response")
		if !responseNode.Exists() {
			if root.Get("candidates").Exists() {
				responseNode = root
			} else {
				if usageMetadataResult := root.Get("usageMetadata"); usageMetadataResult.Exists() {
					usageRaw = usageMetadataResult.Raw
				}
				continue
			}
		}
		responseNodeRaw = responseNode.Raw
		responsePartsRaw = ""
		responsePartsIndex = -1

		if traceResult := root.Get("traceId"); traceResult.Exists() && traceResult.String() != "" {
			traceID = traceResult.String()
		}

		var partsResult ojson.Result
		responseNode.ForEach(func(rk, rv ojson.Result) bool {
			switch rk.String() {
			case "modelVersion":
				if rv.String() != "" {
					modelVersion = rv.String()
				}
			case "responseId":
				if rv.String() != "" {
					responseID = rv.String()
				}
			case "usageMetadata", "cpaUsageMetadata":
				if rk.String() == "usageMetadata" || usageRaw == "" {
					usageRaw = rv.Raw
				}
			case "candidates":
				if rv.IsArray() {
					cand0 := rv.Get("0")
					if cand0.IsObject() {
						cand0.ForEach(func(ck, cv ojson.Result) bool {
							switch ck.String() {
							case "finishReason":
								if cv.String() != "" {
									finishReason = cv.String()
								}
							case "content":
								if cv.IsObject() {
									cv.ForEach(func(ctk, ctv ojson.Result) bool {
										switch ctk.String() {
										case "role":
											role = ctv.String()
										case "parts":
											partsResult = ctv
											responsePartsRaw = ctv.Raw
											responsePartsIndex = ctv.Index - responseNode.Index
										}
										return true
									})
								}
							}
							return true
						})
					}
				}
			}
			return true
		})
		if usageRaw == "" {
			if usageMetadataResult := root.Get("usageMetadata"); usageMetadataResult.Exists() {
				usageRaw = usageMetadataResult.Raw
			}
		}

		if partsResult.IsArray() {
			pendingFromCurrentChunk = false
			partsResult.ForEach(func(_, part ojson.Result) bool {
				var (
					hasFunctionCall bool
					hasInlineData   bool
					hasSnakeInline  bool
					hasSnakeSig     bool
					hasText         bool
					sig             string
					inlineRaw       string
					text            string
					thought         bool
				)
				part.ForEach(func(pk, pv ojson.Result) bool {
					switch pk.String() {
					case "functionCall":
						hasFunctionCall = true
					case "inlineData":
						hasInlineData = true
					case "inline_data":
						hasInlineData = true
						hasSnakeInline = true
						inlineRaw = pv.Raw
					case "thoughtSignature":
						sig = pv.String()
					case "thought_signature":
						hasSnakeSig = true
						if sig == "" {
							sig = pv.String()
						}
					case "text":
						hasText = true
						text = pv.String()
					case "thought":
						thought = pv.Bool()
					}
					return true
				})

				if hasFunctionCall || hasInlineData {
					flushPending()
					parts = append(parts, normalizeRawPart(part, hasSnakeSig, hasSnakeInline, sig, inlineRaw))
					return true
				}

				if thought || hasText {
					if text == "" && sig == "" {
						return true
					}
					kind := "text"
					if thought {
						kind = "thought"
					}
					if !thought && text == "" && sig != "" {
						// Preserve standalone empty-text signature carriers as distinct parts so
						// downstream translators keep streaming/non-streaming parity and never
						// overwrite consecutive detached signatures.
						flushPending()
						encoded, _ := json.Marshal(map[string]any{"text": "", "thoughtSignature": sig})
						parts = append(parts, string(encoded))
						return true
					}
					isThoughtTrailingSig := thought && text == "" && sig != "" && pendingKind == "thought" && pendingThoughtSig == ""
					if pendingKind != "" && (pendingKind != kind || pendingThoughtSig != "" || (pendingFromCurrentChunk && !isThoughtTrailingSig)) {
						flushPending()
					}
					pendingKind = kind
					pendingText.WriteString(text)
					if sig != "" {
						pendingThoughtSig = sig
					}
					pendingFromCurrentChunk = true
					return true
				}

				flushPending()
				parts = append(parts, normalizeRawPart(part, hasSnakeSig, hasSnakeInline, sig, inlineRaw))
				return true
			})
		}
	}
	flushPending()

	var templateDoc *ojson.Doc
	if responseNodeRaw == "" {
		templateDoc = ojson.NewDoc([]byte(`{"candidates":[{"content":{"role":"model","parts":` + antigravityPartsPlaceholder + `}}]}`))
	} else if responsePartsRaw != "" {
		if idx := responsePartsIndex; idx >= 0 && idx+len(responsePartsRaw) <= len(responseNodeRaw) {
			templateBytes := make([]byte, 0, len(responseNodeRaw)-len(responsePartsRaw)+len(antigravityPartsPlaceholder))
			templateBytes = append(templateBytes, responseNodeRaw[:idx]...)
			templateBytes = append(templateBytes, antigravityPartsPlaceholder...)
			templateBytes = append(templateBytes, responseNodeRaw[idx+len(responsePartsRaw):]...)
			templateDoc = ojson.NewDoc(templateBytes)
		} else {
			templateDoc = ojson.NewDoc([]byte(responseNodeRaw))
			_ = templateDoc.SetRawBytes("candidates.0.content.parts", []byte(antigravityPartsPlaceholder))
		}
	} else {
		templateDoc = ojson.NewDoc([]byte(responseNodeRaw))
		_ = templateDoc.SetRawBytes("candidates.0.content.parts", []byte(antigravityPartsPlaceholder))
	}

	if role != "" {
		_ = templateDoc.Set("candidates.0.content.role", role)
	}
	if finishReason != "" {
		_ = templateDoc.Set("candidates.0.finishReason", finishReason)
	}
	if modelVersion != "" {
		_ = templateDoc.Set("modelVersion", modelVersion)
	}
	if responseID != "" {
		_ = templateDoc.Set("responseId", responseID)
	}
	if usageRaw != "" {
		_ = templateDoc.SetRawBytes("usageMetadata", []byte(usageRaw))
	} else if !templateDoc.Get("usageMetadata").Exists() {
		_ = templateDoc.SetRawBytes("usageMetadata", []byte(`{"promptTokenCount":0,"candidatesTokenCount":0,"totalTokenCount":0}`))
	}
	_ = templateDoc.Delete("cpaUsageMetadata")
	templateBytes := templateDoc.Bytes()

	partsTotalLen := 2
	for i, p := range parts {
		if i > 0 {
			partsTotalLen++
		}
		partsTotalLen += len(p)
	}

	traceJSON, _ := json.Marshal(traceID)
	placeholder := ojson.GetBytesNoCopy(templateBytes, "candidates.0.content.parts")
	placeholderIdx := placeholder.Index
	if placeholder.Raw != antigravityPartsPlaceholder || placeholderIdx <= 0 {
		partsJSON := make([]byte, 0, partsTotalLen)
		partsJSON = append(partsJSON, '[')
		for i, p := range parts {
			if i > 0 {
				partsJSON = append(partsJSON, ',')
			}
			partsJSON = append(partsJSON, p...)
		}
		partsJSON = append(partsJSON, ']')
		_ = templateDoc.SetRawBytes("candidates.0.content.parts", partsJSON)
		templateBytes = templateDoc.Bytes()
		output := make([]byte, 0, len(templateBytes)+len(traceJSON)+28)
		output = append(output, `{"response":`...)
		output = append(output, templateBytes...)
		output = append(output, `,"traceId":`...)
		output = append(output, traceJSON...)
		output = append(output, '}')
		return output
	}

	output := make([]byte, 0, len(templateBytes)-len(antigravityPartsPlaceholder)+partsTotalLen+len(traceJSON)+28)
	output = append(output, `{"response":`...)
	output = append(output, templateBytes[:placeholderIdx]...)
	output = append(output, '[')
	for i, p := range parts {
		if i > 0 {
			output = append(output, ',')
		}
		output = append(output, p...)
	}
	output = append(output, ']')
	output = append(output, templateBytes[placeholderIdx+len(antigravityPartsPlaceholder):]...)
	output = append(output, `,"traceId":`...)
	output = append(output, traceJSON...)
	output = append(output, '}')
	return output
}

package executor

import (
	"testing"
	"time"

	"github.com/router-for-me/CLIProxyAPI/v8/internal/config"
	cliproxyauth "github.com/router-for-me/CLIProxyAPI/v8/sdk/cliproxy/auth"
)

func dailyCapTestAuth(id string) *cliproxyauth.Auth {
	return &cliproxyauth.Auth{ID: id}
}

func TestAntigravityDailyCapDisabledByDefault(t *testing.T) {
	resetAntigravityDailyCapForTest()
	auth := dailyCapTestAuth("cap-auth-a")
	if antigravityDailyCapExceeded(auth, &config.Config{}) {
		t.Fatal("cap must be disabled when PerCredentialDailyCap is zero")
	}
	for i := 0; i < 500; i++ {
		antigravityDailyCapRecord(auth)
	}
	if antigravityDailyCapExceeded(auth, &config.Config{}) {
		t.Fatal("cap must stay disabled regardless of recorded volume")
	}
}

func TestAntigravityDailyCapTripsAtLimitAndRotatesDay(t *testing.T) {
	resetAntigravityDailyCapForTest()
	cfg := &config.Config{}
	cfg.Antigravity.PerCredentialDailyCap = 3
	auth := dailyCapTestAuth("cap-auth-b")
	sibling := dailyCapTestAuth("cap-auth-c")

	for i := 0; i < 3; i++ {
		if antigravityDailyCapExceeded(auth, cfg) {
			t.Fatalf("attempt %d must pass under a cap of 3", i+1)
		}
		antigravityDailyCapRecord(auth)
	}
	if !antigravityDailyCapExceeded(auth, cfg) {
		t.Fatal("cap must trip after the configured attempt budget is spent")
	}
	if antigravityDailyCapExceeded(sibling, cfg) {
		t.Fatal("sibling credentials must not inherit the capped credential's count")
	}
	if remaining := antigravityDailyCapRemainingSeconds(time.Now()); remaining < 1 || remaining > 86400 {
		t.Fatalf("remaining seconds out of range: %d", remaining)
	}

	// A UTC day rollover resets the counters, so the credential serves again.
	antigravityDailyCap.mu.Lock()
	antigravityDailyCap.day = "2000-01-01"
	antigravityDailyCap.mu.Unlock()
	if antigravityDailyCapExceeded(auth, cfg) {
		t.Fatal("day rollover must reset the per-credential counter")
	}
	antigravityDailyCapRecord(auth)
	antigravityDailyCap.mu.Lock()
	count := antigravityDailyCap.counts["cap-auth-b"]
	antigravityDailyCap.mu.Unlock()
	if count != 1 {
		t.Fatalf("counter must restart from one after rollover, got %d", count)
	}
}
